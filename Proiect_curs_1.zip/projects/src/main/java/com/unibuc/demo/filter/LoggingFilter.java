package com.unibuc.demo.filter;

import javax.servlet.*;
import java.io.IOException;
import java.util.Enumeration;

public class LoggingFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        System.out.println("LoggingFilter doFilter() is invoked.");
        Enumeration<String> params = req.getParameterNames();
        while (params.hasMoreElements()) {
            String param = params.nextElement();
            System.out.println("Parameter: " + param + "\nValue: " + req.getParameter(param));
        }
        chain.doFilter(req, res);
    }

    @Override
    public void init(FilterConfig config) {

    }

    @Override
    public void destroy() {

    }

}