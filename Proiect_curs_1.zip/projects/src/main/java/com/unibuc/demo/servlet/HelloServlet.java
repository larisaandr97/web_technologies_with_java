package com.unibuc.demo.servlet;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class HelloServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("HelloServlet's doGet() method is invoked.");
        String responseBody = getFormHtml(null);
        response.getWriter().write(responseBody);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        System.out.println("HelloServlet's doPost() method is invoked.");
        String name = request.getParameter("name");
        String responseBody = getFormHtml(name);
        response.getWriter().write(responseBody);
    }

    private String getFormHtml(String name) {
        return "<html>" +
                    "<body>" +
                        "<form action=\'\\hello\' method=\'post\'>" +
                            "<input type=\'text\' name=\'name\' />" +
                            "<button type=\'submit\'>SEND</button>" +
                        "</form>" +
                        ((name != null) ? "<p>Hello, " + name + "!</p>" : "") +
                    "</body>" +
                "</html>";
    }
}