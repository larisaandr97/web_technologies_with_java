package com.unibuc.demo.configuration;

import com.unibuc.demo.filter.LoggingFilter;
import com.unibuc.demo.servlet.HelloServlet;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ServletConfiguration {
    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        return new ServletRegistrationBean(new HelloServlet(), "/hello");
    }

    @Bean
    public FilterRegistrationBean filterRegistrationBean() {
        FilterRegistrationBean bean = new FilterRegistrationBean(new LoggingFilter());
        bean.addServletRegistrationBeans(new ServletRegistrationBean[] {
                servletRegistrationBean()
        });
        return bean;
    }
}
